create definer = dev@`%` event RESET_CONTRACT_SEQ on schedule
    every '1' DAY
        starts '2023-06-01 00:00:00'
    enable
    do
    UPDATE `sequence` s
   SET s.current_val = 1
 WHERE s.seq_name = 'contract_seq';

